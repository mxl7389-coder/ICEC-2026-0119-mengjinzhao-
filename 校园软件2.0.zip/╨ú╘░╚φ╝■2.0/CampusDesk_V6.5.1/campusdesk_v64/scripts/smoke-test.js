'use strict';
/**
 * 冒烟测试：拉起独立实例（端口 5199 + 隔离数据目录），验证
 * 登录鉴权 / 角色权限 / 零预置数据 / SSE 实时日志 / 全部业务接口。
 *
 * 测试账号与业务记录只写入 data/__smoke__，结束后整个目录删除；
 * 不会向日常 data/*.json 添加任何数据。运行日志是真实请求产生，不做填充。
 *
 *   node scripts/smoke-test.js
 */
const path = require('path');
const fs = require('fs');
const { spawn, execFileSync } = require('child_process');
const telemetry = require('../lib/telemetry');
const extractor = require('../lib/extractor');

const ROOT = path.join(__dirname, '..');
const PORT = 5199;
const BASE = 'http://127.0.0.1:' + PORT;
const SMOKE_DIR = path.join(ROOT, 'data', '__smoke__');
// 测试产生的调用与故意触发的报错必须写入隔离日志目录，绝不混进真实 process_logs/
const SMOKE_LOG_DIR = path.join(ROOT, 'process_logs', '__smoke__');
const results = [];

/** 每个会话独立保存 Cookie，模拟不同角色同时在线 */
function makeSession() {
  let cookie = '';
  return {
    get cookie() { return cookie; },
    async req(method, urlPath, body, opts) {
      const headers = { 'Content-Type': 'application/json', ...((opts && opts.headers) || {}) };
      if (cookie) headers.Cookie = cookie;
      const res = await fetch(BASE + urlPath, {
        method, headers,
        redirect: (opts && opts.redirect) || 'follow',
        body: body === undefined ? undefined : JSON.stringify(body),
      });
      const sc = res.headers.get('set-cookie');
      if (sc) {
        const raw = sc.split(';')[0];
        cookie = raw.replace(/^cd_session=/, '') ? raw : '';
      }
      const ct = res.headers.get('content-type') || '';
      const data = ct.includes('json') ? await res.json() : await res.text();
      return { status: res.status, data, headers: res.headers, location: res.headers.get('location') };
    },
  };
}
function check(name, condition, detail) {
  results.push({ name, ok: !!condition, detail });
  console.log((condition ? '  PASS  ' : '  FAIL  ') + name + (detail ? '  → ' + detail : ''));
}
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function waitReady(anon) {
  for (let i = 0; i < 40; i++) {
    try { const r = await anon.req('GET', '/api/health'); if (r.status === 200) return true; } catch (_) {}
    await sleep(150);
  }
  return false;
}

/* --------------------------- SSE 读取工具 --------------------------- */
function readWithTimeout(reader, ms) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error('stream-timeout')), ms);
    reader.read().then(
      (v) => { clearTimeout(timer); resolve(v); },
      (e) => { clearTimeout(timer); reject(e); },
    );
  });
}
function streamReader(res) {
  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  const state = { buf: '', done: false };
  async function until(predicate, timeoutMs) {
    const deadline = Date.now() + timeoutMs;
    while (Date.now() < deadline && !state.done) {
      const chunk = await readWithTimeout(reader, Math.max(200, deadline - Date.now()))
        .catch(() => ({ done: true, value: undefined }));
      if (chunk.done) { state.done = true; break; }
      state.buf += decoder.decode(chunk.value, { stream: true });
      let idx;
      while ((idx = state.buf.indexOf('\n\n')) >= 0) {
        const block = state.buf.slice(0, idx);
        state.buf = state.buf.slice(idx + 2);
        const ev = /^event: (.+)$/m.exec(block);
        const dt = /^data: (.+)$/m.exec(block);
        if (ev && dt) {
          let payload = null;
          try { payload = JSON.parse(dt[1]); } catch (_) {}
          if (predicate({ event: ev[1], data: payload })) return true;
        }
      }
    }
    return false;
  }
  return { until, cancel: () => reader.cancel().catch(() => {}) };
}

async function main() {
  console.log('\n== CampusDesk 冒烟测试（v6.3 · 局域网前置安全 / 本地离线助手 / 日志隔离 / 审计备份）==\n');
  if (!fs.existsSync(SMOKE_DIR)) fs.mkdirSync(SMOKE_DIR, { recursive: true });
  if (!fs.existsSync(SMOKE_LOG_DIR)) fs.mkdirSync(SMOKE_LOG_DIR, { recursive: true });
  const mainLogBefore = telemetry.readDay(telemetry.localDay()).length;
  const child = spawn(process.execPath, [path.join(ROOT, 'server.js')], {
    cwd: ROOT, stdio: 'ignore',
    env: { ...process.env, PORT: String(PORT), CAMPUSDESK_DATA_DIR: SMOKE_DIR,
      CAMPUSDESK_LOG_DIR: SMOKE_LOG_DIR, CAMPUSDESK_LOG_SOURCE: 'smoke' },
  });

  const anon = makeSession();      // 未登录
  const admin = makeSession();     // 管理员
  const student = makeSession();   // 学生
  const teacher = makeSession();   // 教师
  const ordinaryAdmin = makeSession(); // 普通管理员
  let sse = null;

  try {
    if (!await waitReady(anon)) throw new Error('服务未能启动');

    /* ---------- 启动参数：跨终端通用（v6.2 启动兼容） ---------- */
    const help = execFileSync(process.execPath, ['server.js', '--help'],
      { cwd: ROOT, encoding: 'utf-8' });
    check('--help 列出 --lan 局域网参数', help.includes('node server.js --lan'));
    check('--help 同时给出 Bash 与环境变量写法',
      help.includes('LAN=1 node server.js') && help.includes("$env:LAN='1'"));
    const ALT_PORT = 5201;
    const alt = spawn(process.execPath,
      ['server.js', '--lan', '--port', String(ALT_PORT)], {
        cwd: ROOT, stdio: ['ignore', 'pipe', 'pipe'],
        env: { ...process.env, CAMPUSDESK_DATA_DIR: SMOKE_DIR,
          CAMPUSDESK_LOG_DIR: SMOKE_LOG_DIR, CAMPUSDESK_LOG_SOURCE: 'smoke' },
      });
    let altOut = '';
    alt.stdout.on('data', (d) => { altOut += d.toString(); });
    alt.stderr.on('data', (d) => { altOut += d.toString(); });
    let altOk = false;
    try {
      for (let i = 0; i < 30; i++) {
        await sleep(100);
        try {
          const r = await fetch('http://127.0.0.1:' + ALT_PORT + '/api/health');
          if (r.status === 200) { altOk = true; break; }
        } catch (_) {}
      }
      check('--lan --port 真实启动并绑定所有网卡',
        altOk && altOut.includes('0.0.0.0:' + ALT_PORT));
    } finally { alt.kill(); }

    /* ---------- 零预置数据 + 首次初始化 ---------- */
    const h = await anon.req('GET', '/api/health');
    check('服务健康检查', h.data.ok && h.data.initialized === false, 'version=' + h.data.version);
    check('测试日志写入隔离目录，真实日志不被污染',
      !('log_dir' in h.data) && !('log_source' in h.data) &&
      telemetry.readDay(telemetry.localDay()).every((r) => r.source !== 'smoke'),
      '公开健康接口不泄露日志目录与来源配置');
    check('连续天数自检来自真实日期文件', typeof h.data.streak === 'number',
      'streak=' + h.data.streak);
    check('安全响应头已下发（CSP 脚本白名单 / Referrer-Policy）',
      String(h.headers.get('content-security-policy') || '').includes("script-src 'self'") &&
      h.headers.get('referrer-policy') === 'same-origin',
      'CSP=' + (h.headers.get('content-security-policy') || '').slice(0, 30) + '…');
    const state = await anon.req('GET', '/api/auth/state');
    check('首次启动未预置任何账号', state.data.initialized === false && state.data.user === null);
    const unauth = await anon.req('GET', '/api/bootstrap');
    check('未登录访问业务接口被拦截', unauth.status === 401 && unauth.data.error === 'UNAUTHORIZED');

    const setupWrongPortal = await anon.req('POST', '/api/auth/setup', {
      username: 'hacker_portal', password: 'Hack2026x', display_name: 'x', portal: 'user',
    });
    check('首次初始化不能从用户端完成',
      setupWrongPortal.status === 403 && setupWrongPortal.data.error === 'PORTAL_MISMATCH');

    const setup = await admin.req('POST', '/api/auth/setup', {
      username: 'smoke_admin', password: 'Admin2026x', display_name: '测试管理员', portal: 'admin',
    });
    check('首次初始化由使用者创建管理员', setup.status === 201 && setup.data.user.role === 'system_admin');
    const again = await anon.req('POST', '/api/auth/setup', {
      username: 'hacker', password: 'Hack2026x', display_name: 'x',
    });
    check('初始化只能执行一次', again.status === 409 && again.data.error === 'ALREADY_INITIALIZED');
    const me = await admin.req('GET', '/api/auth/me');
    check('会话 Cookie 生效', me.status === 200 && me.data.user.username === 'smoke_admin');
    const badLogin = await anon.req('POST', '/api/auth/login', { username: 'smoke_admin', password: 'wrong-pass-9' });
    check('错误密码被拒绝', badLogin.status === 401 && badLogin.data.error === 'BAD_CREDENTIALS');

    /* ---------- 账号管理 ---------- */
    for (const [username, role, name] of [
      ['smoke_student', 'student', '测试学生'],
      ['smoke_teacher', 'teacher', '测试教师'],
      ['smoke_admin2', 'admin', '普通管理员'],
    ]) {
      const r = await admin.req('POST', '/api/admin/users', {
        username, role, display_name: name, password: 'Campus2026x',
      });
      check('创建 ' + role + ' 账号', r.status === 201 && r.data.role === role);
    }
    await student.req('POST', '/api/auth/login', { username: 'smoke_student', password: 'Campus2026x' });
    await teacher.req('POST', '/api/auth/login', { username: 'smoke_teacher', password: 'Campus2026x' });
    await ordinaryAdmin.req('POST', '/api/auth/login', { username: 'smoke_admin2', password: 'Campus2026x', portal: 'admin' });
    check('学生、教师、普通管理员分别登录成功', student.cookie.length > 10 && teacher.cookie.length > 10 && ordinaryAdmin.cookie.length > 10);
    const ordinaryEq = await ordinaryAdmin.req('GET', '/api/admin/equipment');
    check('普通管理员可访问器材业务管理', ordinaryEq.status === 200);
    const ordinaryLogs = await ordinaryAdmin.req('GET', '/api/logs?days=7');
    check('普通管理员不能查看系统运行日志', ordinaryLogs.status === 403);
    const ordinaryOverview = await ordinaryAdmin.req('GET', '/api/admin/overview');
    check('普通管理员不能读取系统维护总览', ordinaryOverview.status === 403);
    const ordinaryBackup = await ordinaryAdmin.req('GET', '/api/admin/backup');
    check('普通管理员不能导出系统备份', ordinaryBackup.status === 403);
    const adminArea = await student.req('GET', '/api/admin/overview');
    check('学生访问管理接口被拒绝', adminArea.status === 403 && adminArea.data.error === 'FORBIDDEN');
    const logsArea = await student.req('GET', '/api/logs?days=7');
    check('学生访问日志接口被拒绝', logsArea.status === 403);

    const boot = await admin.req('GET', '/api/bootstrap');
    check('bootstrap 零预置业务数据', boot.status === 200 && boot.data.empty === true &&
      boot.data.equipment.items.length === 0 && boot.data.notices.length === 0 &&
      boot.data.mistakes.length === 0 && boot.data.feedback.length === 0,
      'empty=' + boot.data.empty);
    const emptyEq = await student.req('GET', '/api/equipment/list');
    check('器材清单初始为空（不再自动播种）', emptyEq.data.items.length === 0);
    const noAdd = await student.req('POST', '/api/equipment/add', { name: '学生私自添加', total: 2 });
    check('学生不能新增器材', noAdd.status === 403);

    /* ---------- 业务接口（数据只写入隔离目录） ---------- */
    const addEq = await teacher.req('POST', '/api/equipment/add', { name: '测试用垫子', total: 3, category: '体育器材', code: 'SMOKE-MAT-01' });
    check('教师新增器材', addEq.status === 200 && addEq.data.items.length === 1);
    const adminEqInitial = await admin.req('GET', '/api/admin/equipment');
    check('V6.3 管理员器材后台可读取完整档案', adminEqInitial.status === 200 && adminEqInitial.data.items.length === 1);
    const studentAdminEq = await student.req('GET', '/api/admin/equipment');
    check('V6.3 学生不能读取管理员器材后台', studentAdminEq.status === 403);
    const teacherUpdateDenied = await teacher.req('POST', '/api/admin/equipment/update', { id: addEq.data.items[0].id, name: '越权修改', total: 3 });
    check('V6.3 教师不能编辑管理员器材档案', teacherUpdateDenied.status === 403);
    const teacherDeleteDenied = await teacher.req('DELETE', '/api/equipment/delete', { id: addEq.data.items[0].id });
    check('V6.3 教师保留新增但不能删除器材', teacherDeleteDenied.status === 403);
    const equipmentId = addEq.data.items[0].id;
    const updateEq = await admin.req('POST', '/api/admin/equipment/update', { id: equipmentId, name: '测试用垫子（已编辑）', code: 'SMOKE-MAT-01', category: '体育器材', model: 'MAT-X', location: '体育仓库', unit: '个', min_stock: 1, total: 999 });
    check('V6.3 管理员编辑器材档案（编辑不直接改库存）', updateEq.status === 200 && updateEq.data.item.model === 'MAT-X' && updateEq.data.item.total === 3);
    const adjustEq = await admin.req('POST', '/api/admin/equipment/adjust', { id: equipmentId, delta: 2, reason: '测试入库' });
    check('V6.3 管理员库存调整并记录原因', adjustEq.status === 200 && adjustEq.data.item.total === 5);
    const badAdjust = await admin.req('POST', '/api/admin/equipment/adjust', { id: equipmentId, delta: -99, reason: '非法减少' });
    check('V6.3 库存调整不能低于在借数量 / 零库存', badAdjust.status === 400);
    const importEq = await admin.req('POST', '/api/admin/equipment/import', { items: [
      { '器材名称': '批量导入测试示波器', '器材编号': 'SMOKE-SCOPE-01', '分类': '电子仪器', '型号': 'S-100', '总数量': '2', '单位': '台', '存放位置': '实验室A', '最低库存': '1' },
      { name: '批量导入测试万用表', code: 'SMOKE-METER-01', category: '电子仪器', total: 4, unit: '台' },
    ] });
    check('V6.3 管理员批量导入两条器材记录', importEq.status === 201 && importEq.data.imported === 2);
    const duplicateImport = await admin.req('POST', '/api/admin/equipment/import', { items: [{ name: '重复编号', code: 'SMOKE-MAT-01', total: 1 }] });
    check('V6.3 批量导入重复编号整批拒绝', duplicateImport.status === 400);
    const archiveEq = await admin.req('POST', '/api/admin/equipment/archive', { id: importEq.data.items[0].id });
    const userEqAfterArchive = await student.req('GET', '/api/equipment/list');
    check('V6.3 归档器材从用户借用列表隐藏', archiveEq.status === 200 && !userEqAfterArchive.data.items.some((x) => x.id === importEq.data.items[0].id));
    const restoreEq = await admin.req('POST', '/api/admin/equipment/restore', { id: importEq.data.items[0].id });
    check('V6.3 管理员可以恢复已归档器材', restoreEq.status === 200);
    const duplicateCode = await teacher.req('POST', '/api/equipment/add', { name: '重复编号器材', code: 'SMOKE-MAT-01', total: 1 });
    check('V6.3 新增器材时拒绝重复编号', duplicateCode.status === 400);
    const eq = (await admin.req('GET', '/api/equipment/list')).data;
    const item = eq.items[0];

    const samples = extractor.SAMPLES; // 测试夹具，仅用于校验解析器，不写入日常数据
    let savedId = null;
    for (const s of samples) {
      const r = await student.req('POST', '/api/notice/parse', { text: s.text });
      check('通知解析 · ' + s.label, r.status === 200 && r.data.title,
        'conf=' + (r.data.confidence || 0) + '%');
      if (!savedId && r.status === 200) {
        const save = await student.req('POST', '/api/notice/save', { notice: r.data });
        savedId = save.data.id;
      }
    }
    const stuList = await student.req('GET', '/api/notice/list');
    const teaList = await teacher.req('GET', '/api/notice/list');
    check('学生只见自己录入的通知', stuList.data.items.length === 1 && teaList.data.items.length === 1);
    check('通知保存与待办勾选', savedId &&
      (await student.req('POST', '/api/notice/toggle', { id: savedId })).status === 200);
    const ics = await student.req('GET', '/api/notice/ics?id=' + savedId);
    check('日历 .ics 导出', ics.status === 200 && String(ics.data).includes('BEGIN:VCALENDAR'));
    const emptyNotice = await student.req('POST', '/api/notice/parse', { text: '' });
    check('错误路径 · 空通知被拦截', emptyNotice.status === 400 && emptyNotice.data.error === 'EMPTY_NOTICE');
    const noDelete = await student.req('DELETE', '/api/notice/delete', { id: savedId });
    check('学生不能删除通知', noDelete.status === 403);

    const loan = await student.req('POST', '/api/loan/create', {
      item_id: item.id, borrower: '测试同学', qty: 2, due_date: '2026-11-01', purpose: '冒烟测试',
    });
    check('学生登记借出（构造逾期）', loan.status === 200 && loan.data.overdue_count >= 1);
    const loanRow = loan.data.loans.find((l) => l.borrower === '测试同学');
    const partial = await student.req('POST', '/api/loan/return', { id: loanRow.id, returned_qty: 1 });
    check('部分归还核对', partial.data.loans.find((l) => l.id === loanRow.id).left === 1);
    const full = await student.req('POST', '/api/loan/return', { id: loanRow.id, returned_qty: 1 });
    check('全部归还核对', full.data.loans.find((l) => l.id === loanRow.id).status === 'returned');
    const over = await student.req('POST', '/api/loan/create', {
      item_id: item.id, borrower: '超额', qty: 9999, due_date: '2026-12-01',
    });
    check('错误路径 · 库存不足被拦截', over.status === 400 && over.data.error === 'OUT_OF_STOCK');

    const ms = await student.req('POST', '/api/mistake/add', {
      title: '测试题：函数定义域', subject: '数学', knowledge: '函数',
      wrong_reason: '漏看定义域', correct_answer: '先求定义域',
    });
    check('错题录入', ms.status === 200 && ms.data.next_review);
    const r1 = await student.req('POST', '/api/mistake/review', { id: ms.data.id, result: 'ok' });
    check('复习进阶', r1.data.stage === 1);
    const r2 = await student.req('POST', '/api/mistake/review', { id: ms.data.id, result: 'again' });
    check('复习重置', r2.data.stage === 0 && r2.data.review_count === 2);
    check('错题列表', (await student.req('GET', '/api/mistake/list')).data.items.length === 1);

    const fb = await student.req('POST', '/api/feedback/add', { role: '自动化测试', module: '整体', score: 4 });
    check('反馈提交', fb.status === 200);
    const fbList = await student.req('GET', '/api/feedback/list');
    check('学生不能查看他人反馈汇总', fbList.status === 403);
    check('未知路由返回 404', (await admin.req('GET', '/api/not-exist')).status === 404);

    /* ---------- v6 · SRS 对齐的真实能力 ---------- */
    const extra = await student.req('POST', '/api/notice/parse', {
      text: '教务处发布：关于期末考试安排的通知。请全体同学务必于12月20日前携带学生证、准考证到办公楼301参加，联系人：王老师，逾期不再受理。发布单位：教务处',
    });
    check('提取引擎补齐 SRS 字段（发布单位 / 材料 / 重要程度）',
      extra.data.issuer === '教务处' && extra.data.materials.length >= 1 && extra.data.importance === '紧急',
      'issuer=' + extra.data.issuer + ', materials=' + extra.data.materials.join('/') + ', importance=' + extra.data.importance);
    check('提取结果标记「需人工审核」且引擎为本地规则',
      extra.data.reviewed === false && extra.data.extract_engine === 'local-rules');

    const dash = await student.req('GET', '/api/dashboard');
    check('CM-FR-001 仪表盘指标齐备且含真实系统读数',
      !!dash.data.notice && !!dash.data.loan && !!dash.data.equipment &&
      !!dash.data.system && typeof dash.data.system.uptime_s === 'number' &&
      typeof dash.data.system.rss_mb === 'number' && typeof dash.data.telemetry.today_calls === 'number',
      'uptime=' + dash.data.system.uptime_s + 's, rss=' + dash.data.system.rss_mb + 'MB');

    const act = await student.req('GET', '/api/activity?days=7');
    check('最近操作足迹只返回当前会话的脱敏摘要',
      act.status === 200 && act.data.scope === 'own_session' && act.data.items.length > 0 &&
      act.data.items.every((r) => !('text' in r) && !('module' in r) && !('action' in r) && !('status' in r) && !('duration_ms' in r) && !('error_code' in r) && typeof r.title === 'string' && typeof r.action_label === 'string'),
      act.data.items.length + ' 条');
    check('未登录不能读取操作足迹', (await anon.req('GET', '/api/activity')).status === 401);

    const eqArchive = await teacher.req('POST', '/api/equipment/add', {
      name: '档案测试仪器', total: 2, code: 'EQ-CHK-001', model: 'TEST-2000',
      location: '实验楼B203', purchased_at: '2026-01-15', unit: '台', note: '需定期校准',
    });
    const archived = eqArchive.data.items.find((i) => i.code === 'EQ-CHK-001');
    check('CM-FR-201 器材档案完整字段真实落库',
      !!archived && archived.model === 'TEST-2000' && archived.location === '实验楼B203' &&
      archived.purchased_at === '2026-01-15' && archived.note === '需定期校准');

    const ov = await admin.req('GET', '/api/admin/overview');
    check('CM-FR-509 健康检查项与资源为真实读数',
      Array.isArray(ov.data.checks) && ov.data.checks.length === 6 &&
      typeof ov.data.resources.rss_mb === 'number' && ov.data.checks.every((c) => typeof c.ok === 'boolean'),
      ov.data.checks.filter((c) => c.ok).length + '/' + ov.data.checks.length + ' 项通过');
    check('管理总览含连续天数自检对象', !!ov.data.streak &&
      typeof ov.data.streak.current_streak === 'number' && Array.isArray(ov.data.streak.gaps),
      '连续 ' + ov.data.streak.current_streak + ' 天 / 累计 ' + ov.data.streak.days_count + ' 天');
    check('版本时间线来自真实 git log', Array.isArray(ov.data.git_commits), (ov.data.git_commits || []).length + ' 条提交');
    check('日报文件清单可读', Array.isArray(ov.data.report_files));

    const expJson = await admin.req('GET', '/api/admin/export?format=json');
    check('CM-FR-507 导出 JSON 日志',
      expJson.status === 200 && expJson.data && Array.isArray(expJson.data.rows) && expJson.data.rows.length > 0,
      expJson.data ? expJson.data.row_count + ' 行' : '');
    const expCsv = await admin.req('GET', '/api/admin/export?format=csv');
    check('CM-FR-507 导出 CSV 日志',
      expCsv.status === 200 && String(expCsv.data).indexOf('ts,day,app_version') >= 0 &&
      String(expCsv.data).split('\r\n').length > 2);
    check('导出响应带下载文件名', /attachment; filename=/.test(expCsv.headers.get('content-disposition') || ''));
    check('学生不能导出运行日志', (await student.req('GET', '/api/admin/export?format=json')).status === 403);
    const sumRoles = await admin.req('GET', '/api/admin/summary?days=7');
    check('日志按角色聚合可用', Object.keys(sumRoles.data.by_role || {}).length >= 1, JSON.stringify(sumRoles.data.by_role));

    /* ---------- v6.1 · 日志隔离之外的新增真实能力 ---------- */
    for (const t of ['paste', 'txt', 'md', 'csv', 'json']) {
      const r = await student.req('POST', '/api/notice/parse', {
        text: extractor.SAMPLES[1].text, import_type: t,
      });
      check('CM-FR-101 导入方式 ' + t, r.status === 200 && r.data.import_type === t);
    }
    const badImport = await student.req('POST', '/api/notice/parse', {
      text: extractor.SAMPLES[1].text, import_type: 'pdf',
    });
    check('未实现的导入类型如实回退为手动粘贴', badImport.data.import_type === 'paste');

    const dupParse = await student.req('POST', '/api/notice/parse', { text: extractor.SAMPLES[0].text });
    check('CM-FR-109 重复通知识别（只给相似度，不泄露他人原文）',
      dupParse.data.duplicate_hint && dupParse.data.duplicate_hint.detected === true &&
      dupParse.data.duplicate_hint.top_similarity >= 90 &&
      !('duplicate_title' in dupParse.data.duplicate_hint),
      'top=' + dupParse.data.duplicate_hint.top_similarity + '%');

    const icsDay = await student.req('POST', '/api/notice/preview', {
      notice: dupParse.data, remind_minutes: 1440,
    });
    check('CM-FR-107 自定义提前提醒写入 .ics', String(icsDay.data.ics).includes('TRIGGER:-P1D'));
    const icsNone = await student.req('POST', '/api/notice/preview', {
      notice: dupParse.data, remind_minutes: 0,
    });
    check('提醒设为 0 时不生成 VALARM', !String(icsNone.data.ics).includes('VALARM'));

    const revisedText = extractor.SAMPLES[0].text.replace('A301', 'B205');
    const preview = await student.req('POST', '/api/notice/revise', { id: savedId, text: revisedText });
    check('CM-FR-110 版本比对先预览、不直接落库',
      preview.status === 200 && preview.data.applied === false &&
      Array.isArray(preview.data.changes) && preview.data.changes.length > 0,
      preview.data.changes.length + ' 处字段变化');
    const applied = await student.req('POST', '/api/notice/revise', {
      id: savedId, text: revisedText, apply: true,
    });
    check('CM-FR-110 人工确认后写入 v2 并保留历史快照',
      applied.data.applied === true && applied.data.notice.version === 2 &&
      applied.data.notice.history.length === 1);

    const fb2 = await student.req('POST', '/api/feedback/add', {
      role: '大二学生', module: '通知提取', score: 5,
      task_done: '导入并人工审核了一条通知', problem: '希望尽快支持 Word 导入', reuse: '愿意',
    });
    check('反馈字段对齐 8 份问卷（实际任务 / 问题 / 再用意愿）',
      !!fb2.data.task_done && !!fb2.data.problem && fb2.data.reuse === '愿意');
    const prog = await student.req('GET', '/api/feedback/progress');
    check('收集进度对所有登录用户可见（只有数量）',
      prog.status === 200 && prog.data.collected === 2 && prog.data.target === 8 &&
      !('items' in prog.data));
    const fbAdmin = await admin.req('GET', '/api/admin/feedback');
    check('管理端可查看反馈明细', fbAdmin.status === 200 && fbAdmin.data.items.length === 2 &&
      fbAdmin.data.items.some((f) => f.task_done));

    const au = await admin.req('GET', '/api/admin/audit');
    check('CM-FR-210 业务审计真实记录且不含原文 / 姓名',
      au.status === 200 && au.data.items.length > 0 &&
      au.data.items.every((x) => !('raw_text' in x) && !('owner_name' in x) &&
        !('text' in x) && !('title' in x)), au.data.items.length + ' 条');

    const snap = await admin.req('GET', '/api/admin/backup');
    check('4.3 业务数据备份快照含 checksum 与数据集',
      snap.status === 200 && snap.data.format === 'campusdesk-backup' &&
      /^[a-f0-9]{64}$/.test(snap.data.checksum || '') && !!snap.data.datasets.notices);
    const verify = await admin.req('POST', '/api/admin/backup/verify', { backup: snap.data });
    check('备份完整性校验通过（SHA256 重算）', verify.status === 200 && verify.data.ok === true);
    const tampered = await admin.req('POST', '/api/admin/backup/verify', {
      backup: { ...snap.data, checksum: '0'.repeat(64) },
    });
    check('被篡改的备份校验不通过且不写入数据',
      tampered.status === 200 && tampered.data.ok === false && tampered.data.checksum_matched === false);
    const noConfirm = await admin.req('POST', '/api/admin/backup/restore', { backup: snap.data });
    check('恢复必须显式确认', noConfirm.status === 400 && noConfirm.data.error === 'RESTORE_NOT_CONFIRMED');
    const restore = await admin.req('POST', '/api/admin/backup/restore', {
      backup: snap.data, confirm: 'RESTORE',
    });
    check('确认后恢复业务数据（不动账号与会话）', restore.status === 200 && restore.data.ok === true);

    const csrf = await anon.req('POST', '/api/auth/login', {
      username: 'smoke_admin', password: 'Admin2026x',
    }, { headers: { Origin: 'http://evil.example' } });
    check('跨站 Origin 写请求被 CSRF 校验拦截',
      csrf.status === 403 && csrf.data.error === 'CSRF_ORIGIN_MISMATCH');

    /* ---------- 三套独立入口、页面级越权与旧链接兼容 ---------- */
    const manual = { redirect: 'manual' };
    const coverPage = await anon.req('GET', '/', undefined, manual);
    check('动态封面总入口可匿名访问',
      coverPage.status === 200 && String(coverPage.data).includes('把校园里的琐事'));
    const userLoginPage = await anon.req('GET', '/user/', undefined, manual);
    check('用户端独立登录页可访问',
      userLoginPage.status === 200 && String(userLoginPage.data).includes('案头有常课'));
    const adminLoginPage = await anon.req('GET', '/admin/', undefined, manual);
    check('管理端独立登录页可访问',
      adminLoginPage.status === 200 && String(adminLoginPage.data).includes('运行皆有迹'));
    check('两端登录页互不出现对方入口',
      !String(userLoginPage.data).includes('/admin/') && !String(adminLoginPage.data).includes('/user/'));
    const portalCss = await anon.req('GET', '/portal.css', undefined, manual);
    check('书院风封面样式资源可访问',
      portalCss.status === 200 && String(portalCss.data).includes('@keyframes leafFall'));
    const portalJs = await anon.req('GET', '/portal.js', undefined, manual);
    check('入口脚本资源可访问', portalJs.status === 200);

    const uPage = await student.req('GET', '/user/index.html', undefined, manual);
    check('用户端八大视图与 v6.1 新组件齐备',
      ['view-dashboard', 'view-notice', 'view-equipment', 'view-mistake', 'view-assistant', 'view-activity', 'view-feedback', 'view-about',
        'notice-file', 'import-info', 'revise-notice', 'revise-text', 'btn-revise-preview',
        'fb-task', 'fb-problem', 'fb-reuse', 'sys-strip']
        .every((id) => String(uPage.data).includes('id="' + id + '"')) &&
      String(uPage.data).includes('CM-FR-001'));
    const aPage = await admin.req('GET', '/admin/index.html', undefined, manual);
    check('管理端八大视图与 v6.1 新组件齐备',
      ['view-live', 'view-health', 'view-analytics', 'view-users', 'view-data', 'view-feedback', 'view-backup', 'view-about',
        'btn-backup-export', 'backup-file', 'backup-verify', 'audit-table', 'fb-slots', 'health-checks', 'perm-matrix']
        .every((id) => String(aPage.data).includes('id="' + id + '"')));

    const uIdxAnon = await anon.req('GET', '/user/index.html', undefined, manual);
    check('未登录访问用户工作台→本端登录页',
      uIdxAnon.status === 302 && uIdxAnon.location === '/user/login.html');
    const aIdxAnon = await anon.req('GET', '/admin/index.html', undefined, manual);
    check('未登录访问管理后台→本端登录页',
      aIdxAnon.status === 302 && aIdxAnon.location === '/admin/login.html');
    const upper = await anon.req('GET', '/ADMIN/INDEX.HTML', undefined, manual);
    check('大小写变体不能绕过页面鉴权',
      upper.status === 302 && upper.location === '/admin/login.html');
    const aIdxStu = await student.req('GET', '/admin/index.html', undefined, manual);
    check('学生不能进入管理端页面',
      aIdxStu.status === 302 && aIdxStu.location === '/admin/login.html');
    const uIdxAdmin = await admin.req('GET', '/user/index.html', undefined, manual);
    check('管理员不能进入用户端页面',
      uIdxAdmin.status === 302 && uIdxAdmin.location === '/user/login.html');
    const uLoginByStu = await student.req('GET', '/user/', undefined, manual);
    check('已登录用户端跳过登录页直达工作台',
      uLoginByStu.status === 302 && uLoginByStu.location === '/user/index.html');
    const aLoginByAdmin = await admin.req('GET', '/admin/', undefined, manual);
    check('已登录管理端跳过登录页直达后台',
      aLoginByAdmin.status === 302 && aLoginByAdmin.location === '/admin/index.html');

    for (const [oldPath, target] of [
      ['/login.html', '/'], ['/index.html', '/user/'], ['/admin.html', '/admin/'],
      ['/app.js', '/user/app.js'], ['/admin.js', '/admin/admin.js'],
    ]) {
      const r = await anon.req('GET', oldPath, undefined, manual);
      check('旧链接兼容 ' + oldPath, r.status === 302 && r.location === target);
    }

    /* ---------- 管理员后台：实时日志 ---------- */
    const ctrl = new AbortController();
    const sseRes = await fetch(BASE + '/api/admin/stream', {
      headers: { Cookie: admin.cookie }, signal: ctrl.signal,
    });
    check('SSE 实时流连接', sseRes.status === 200 &&
      (sseRes.headers.get('content-type') || '').includes('text/event-stream'));
    sse = streamReader(sseRes);
    const gotSnapshot = await sse.until((e) => e.event === 'snapshot' && e.data && Array.isArray(e.data.recent), 6000);
    check('SSE 首帧下发快照', gotSnapshot);
    // 连接保持期间再发一次请求，应收到服务端主动推送的 log 事件
    await anon.req('GET', '/api/health');
    const gotPush = await sse.until((e) => e.event === 'log' && e.data && e.data.module === 'health', 6000);
    check('新日志实时推送到后台', gotPush);

    const poll = await admin.req('GET', '/api/admin/poll?cursor=0');
    check('轮询兜底按游标返回', poll.status === 200 && poll.data.rows.length > 0 && poll.data.cursor > 0,
      'cursor=' + poll.data.cursor);
    const summary = await admin.req('GET', '/api/admin/summary?days=7');
    check('日志汇总可用', summary.data.total_calls > 15, '累计 ' + summary.data.total_calls + ' 次调用');
    check('日志含报错记录', (summary.data.by_status.error || 0) >= 3,
      '报错 ' + (summary.data.by_status.error || 0) + ' 次');
    check('错误码聚合可用', Object.keys(summary.data.by_error_code || {}).length >= 3,
      Object.keys(summary.data.by_error_code || {}).join(','));
    const day = await admin.req('GET', '/api/admin/day?date=' + telemetry.localDay());
    check('按天读取日志', day.data.rows.length > 0);
    check('日志含角色字段', day.data.rows.some((r) => r.role === 'student' || r.role === 'system_admin'));
    const v4rows = day.data.rows.filter((r) => r.app_version === 'v6.4.0');
    check('单请求库存快照计算 ≤1 次', v4rows.length > 0 &&
      v4rows.every((r) => (r.meta.reconcile_calls || 0) <= 1));
    const overview = await admin.req('GET', '/api/admin/overview');
    // v6 新增的「器材档案完整字段」用例会多写入 1 条器材，故此处期望 2
    check('数据总览含数据集条数', overview.data.datasets.notices === 1 &&
      overview.data.datasets.equipment === 4 && overview.data.users_total === 4);
    const users = await admin.req('GET', '/api/admin/users');
    check('账号列表不泄露密码哈希', users.data.items.length === 4 &&
      users.data.items.every((u) => !('password_hash' in u) && !('salt' in u)));
    const report = await admin.req('POST', '/api/admin/report', {});
    check('当日日报生成', report.data.ok);

    /* ---------- v6.2 本地离线辅助助手 ---------- */
    // 前面保存的那条已被 toggle 标记完成；这里补一条带截止的未完成通知验证来源标注
    const dated = await student.req('POST', '/api/notice/save', {
      notice: { title: '带截止的测试通知', category: '教务',
        event_date: '2026-11-25', deadline: '2026-11-24', location: '教三 201' },
    });
    check('助手测试夹具：带截止日期的通知已入库',
      dated.status === 200 && dated.data.deadline === '2026-11-24');
    const aiAnon = await anon.req('POST', '/api/assistant/ask', { question: '最近的截止是什么' });
    check('助手接口需要登录', aiAnon.status === 401);
    const aiEmpty = await student.req('POST', '/api/assistant/ask', { question: '' });
    check('空问题被拒绝', aiEmpty.status === 400 && aiEmpty.data.error === 'EMPTY_QUESTION');
    const aiHelp = await student.req('POST', '/api/assistant/ask', { question: '你能做什么' });
    check('助手标明本地规则引擎与能力说明', aiHelp.status === 200 &&
      aiHelp.data.engine === 'local-rules' && aiHelp.data.answered === true && aiHelp.data.intent === 'help');
    const aiDeadline = await student.req('POST', '/api/assistant/ask', { question: '最近的截止是什么' });
    check('截止查询回答附资料来源', aiDeadline.status === 200 && aiDeadline.data.answered === true &&
      aiDeadline.data.sources.length > 0 &&
      aiDeadline.data.sources.every((s) => s.type === 'notice' && s.id && s.title) &&
      aiDeadline.data.sources.some((s) => s.id === dated.data.id && s.value === '2026-11-24'));
    const aiEq = await student.req('POST', '/api/assistant/ask', { question: '器材还有几台可用' });
    check('器材库存查询可用', aiEq.status === 200 && aiEq.data.answered === true &&
      aiEq.data.sources.some((s) => s.type === 'equipment'));
    const aiUnknown = await student.req('POST', '/api/assistant/ask',
      { question: '帮我预测一下明天的股票走势好吗' });
    check('超出能力的问题明确拒答、不编造', aiUnknown.status === 200 &&
      aiUnknown.data.answered === false && /不会|无法/.test(aiUnknown.data.text));
    const secret = 'ZZ私密问题串_' + Date.now();
    await student.req('POST', '/api/assistant/ask', { question: secret });
    const aiDayFile = path.join(SMOKE_LOG_DIR, telemetry.localDay() + '.jsonl');
    const aiLogText = fs.existsSync(aiDayFile) ? fs.readFileSync(aiDayFile, 'utf8') : '';
    check('助手问题原文不写入日志', !aiLogText.includes(secret));
    const privateTitle = '教师专属内部通知标记ABC123';
    await teacher.req('POST', '/api/notice/save',
      { notice: { title: privateTitle, category: '教务', event_date: '2026-12-01', deadline: '2026-12-01' } });
    const aiScoped = await student.req('POST', '/api/assistant/ask', { question: '有哪些通知' });
    check('学生助手回答不含他人通知', aiScoped.status === 200 &&
      !String(aiScoped.data.text).includes(privateTitle) &&
      aiScoped.data.sources.every((s) => s.title !== privateTitle));
    const mePerm = await student.req('GET', '/api/auth/me');
    check('助手权限点已下发给登录用户',
      (mePerm.data.permissions || []).includes('assistant.ask'));

    /* ---------- v6.2 上线前置安全项 ---------- */
    const fakeId = 'FAKE_CLIENT_ID_123';
    const fakeSave = await teacher.req('POST', '/api/notice/save',
      { notice: { id: fakeId, title: '伪造主键测试', event_date: '2026-12-02' } });
    check('通知主键由服务端生成，客户端不能伪造', fakeSave.status === 200 &&
      fakeSave.data.id !== fakeId && String(fakeSave.data.id).startsWith('nt_'));
    const eqAll = await teacher.req('GET', '/api/equipment/list');
    const someItem = (eqAll.data.items || []).find((x) => x.available > 0);
    let loanDenied = false;
    if (someItem) {
      const tLoan = await teacher.req('POST', '/api/loan/create',
        { item_id: someItem.id, qty: 1, borrower: '教师本人' });
      const tRow = tLoan.status === 200 && (tLoan.data.loans || []).find((l) => l.borrower === '教师本人');
      if (tRow) {
        const denied = await student.req('POST', '/api/loan/return', { id: tRow.id, returned_qty: 1 });
        loanDenied = denied.status === 403 && denied.data.error === 'FORBIDDEN';
      }
    }
    check('学生不能归还他人登记的借用', loanDenied);
    const badUrl = await anon.req('GET', '/api/health/%E0%A4%A');
    const alive = await anon.req('GET', '/api/health');
    check('畸形 URL 不打挂服务', badUrl.status < 500 && alive.status === 200 && alive.data.ok === true);
    const badCookie = await anon.req('GET', '/api/health', undefined,
      { headers: { Cookie: 'cd_session=%ZZ' } });
    check('畸形 Cookie 不打挂服务', badCookie.status === 200);

    /* ---------- 退出登录 ---------- */
    const out = await student.req('POST', '/api/auth/logout', {});
    check('退出登录清除会话', out.status === 200 && student.cookie === '');
    check('退出后接口不可访问', (await student.req('GET', '/api/dashboard')).status === 401);

    /* ---------- 入口角色约束：服务端二次校验 ---------- */
    const probe = makeSession();
    const adminAtUser = await probe.req('POST', '/api/auth/login', {
      username: 'smoke_admin', password: 'Admin2026x', portal: 'user',
    });
    check('管理员账号不能从用户端登录',
      adminAtUser.status === 403 && adminAtUser.data.error === 'PORTAL_MISMATCH');
    const studentAtAdmin = await probe.req('POST', '/api/auth/login', {
      username: 'smoke_student', password: 'Campus2026x', portal: 'admin',
    });
    check('学生账号不能从管理端登录',
      studentAtAdmin.status === 403 && studentAtAdmin.data.error === 'PORTAL_MISMATCH');
    const studentAtUser = await probe.req('POST', '/api/auth/login', {
      username: 'smoke_student', password: 'Campus2026x', portal: 'user',
    });
    check('用户端入口可正常登录', studentAtUser.status === 200);
    const adminAtAdmin = await probe.req('POST', '/api/auth/login', {
      username: 'smoke_admin', password: 'Admin2026x', portal: 'admin',
    });
    check('管理端入口可正常登录', adminAtAdmin.status === 200);

    check('全程未向真实日志写入任何 smoke 记录',
      telemetry.readDay(telemetry.localDay()).every((r) => r.source !== 'smoke'),
      '主日志 ' + mainLogBefore + ' → ' + telemetry.readDay(telemetry.localDay()).length + ' 行（并发访问不计入断言）');

    sse.cancel(); ctrl.abort();
    const pass = results.filter((r) => r.ok).length;
    console.log('\n结果：' + pass + '/' + results.length + ' 项通过');
    console.log('测试业务数据已在隔离目录清理；运行日志为真实请求自动采集，未做任何填充\n');
    if (pass !== results.length) process.exitCode = 1;
  } finally {
    if (sse) sse.cancel();
    child.kill();
    // 只清理本脚本创建的隔离数据目录，绝不触碰日常 data/*.json
    if (SMOKE_DIR.endsWith('__smoke__') && fs.existsSync(SMOKE_DIR)) {
      fs.rmSync(SMOKE_DIR, { recursive: true, force: true });
    }
    if (SMOKE_LOG_DIR.endsWith('__smoke__') && fs.existsSync(SMOKE_LOG_DIR)) {
      fs.rmSync(SMOKE_LOG_DIR, { recursive: true, force: true });
    }
  }
}

main().catch((err) => { console.error('[smoke-test] 失败：', err); process.exitCode = 1; });
